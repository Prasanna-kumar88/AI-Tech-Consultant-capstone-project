# Design — AI Tech Consultant
**Prepared by Prasanna Kumar Pachigolla**

## 1. Problem and product choice
Small software businesses spend time finding product facts, answering repeated emails and turning conversations into scoped delivery plans. The system should reduce this coordination cost without inventing product policy or committing to unapproved work. I chose three narrow services with explicit API boundaries because each has a distinct job and can be tested separately.

## 2. Features chosen and why
### Task 1: Knowledge Brain
- Reads the official Brilliant Directories sitemap, with bounded batches and a delay between requests.
- Persists each successful page immediately so interrupted runs can retry safely.
- Hashes article content and image metadata to identify changed pages.
- Marks pages missing from a successfully fetched sitemap as inactive.
- Returns article URLs with answers.
- Creates a human task when no relevant evidence is found; an expert answer is added to retrievable memory.
- Stores user feedback for review instead of silently changing trusted policy.

**Image handling:** the crawler records image URLs, alt text and captions, and attempts best-effort Claude vision descriptions for up to five images per article when an API key is configured. Descriptions are stored with the parent article. Without a key or when an image fails to fetch, it preserves alt/caption metadata and records that visual analysis was unavailable. This path still needs end-to-end evaluation on screenshot-only questions.

### Task 2: Inbox Agent
- Uses strict TypeScript and schema validation.
- Classifies common request kinds, calls Task 1's search API and drafts an answer grounded in retrieved context.
- Stores draft/final reply pairs and tracks unchanged approved drafts by category.
- Implements the 20-in-a-row eligibility rule as a gate, not as an automatic send action. Sensitive categories stay human-reviewed.
- Allows an admin to revoke autonomous eligibility. Real sending is intentionally not wired to an email provider.

### Task 3: Meeting to Scope
- Uses a requirements analyst, product capability analyst, engineering estimator and proposal writer as sequential agents.
- Calls Task 1 before estimating custom development.
- Produces scope, task estimate and proposal output, with assumptions and open questions.
- Accepts a previous scope so follow-up changes can be classified.
- Always returns a human-approval requirement.

## 3. Architecture
```text
                 ┌───────────────────────────┐
                 │ Task 1: Knowledge Brain   │
                 │ Python / FastAPI / SQLite │
                 │ sitemap → articles → RAG  │
                 └─────────────┬─────────────┘
                               │ HTTP search API
                 ┌─────────────┴─────────────┐
                 │                           │
     ┌───────────▼──────────┐    ┌───────────▼──────────┐
     │ Task 2: Inbox Agent  │    │ Task 3: Scope Team   │
     │ TypeScript / Express │    │ Python / FastAPI     │
     │ classify → draft     │    │ analyse → fit check  │
     │ feedback → gate      │    │ estimate → proposal  │
     └──────────────────────┘    └──────────────────────┘
```

## 4. Model choices and evaluation
Claude is the intended model provider. The code defaults to a Claude Haiku model for cost-sensitive drafts and extraction, configurable through `ANTHROPIC_MODEL`. This is a starting hypothesis, not a measured winner. `evals/` defines 20 scenarios per task. The required comparison must run at least two Claude configurations on the same cases and record accuracy, groundedness, schema validity, cost and latency. I have not fabricated those results.

## 5. What I dropped and why
- Automatic outbound email sending: dropped to avoid unsafe customer communication before reliability is measured.
- Fully automatic scope/proposal sending: dropped because commercial commitments need human approval.
- Vector database: initial version uses transparent lexical retrieval to keep setup small; semantic search is a priority.
- Screenshot vision analysis: not complete in this version; image metadata is stored, but the brief requires actual image understanding.
- Full email provider integration and OAuth: omitted because no credentials or provider were supplied.
- Production multi-tenant UI: omitted in favour of API docs and runnable service boundaries.

## 6. Failure modes and recovery
- Sitemap fetch failure should fail the refresh rather than deactivate all content. Page-level errors are returned and successful pages remain persisted.
- An article missing from a successful sitemap is marked inactive so it is not returned by search.
- Model failure returns a conservative fallback and keeps human approval.
- Empty retrieval escalates to a human task.
- Malicious instructions inside emails, transcripts or retrieved pages are treated as untrusted data.
- Production follow-up: retries with exponential backoff, per-host rate limits, robots.txt compliance, crawl checkpoints, canonical URL tests, authentication, monitoring and tenant isolation.

## 7. What I would build next
1. Complete Claude vision image descriptions and store image-to-article links.
2. Add semantic embeddings, reranking and retrieval evaluations.
3. Add a proper feedback review screen and versioned prompt releases.
4. Add a durable scheduler and source-level freshness dashboard.
5. Run all test suites and report real quality/cost/speed measurements.
6. Record a demo showing all three tasks, including a deliberate failure and escalation.
