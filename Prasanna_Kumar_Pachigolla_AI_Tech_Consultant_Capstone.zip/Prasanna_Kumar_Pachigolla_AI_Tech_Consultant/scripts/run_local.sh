#!/usr/bin/env bash
set -euo pipefail
uvicorn task1_knowledge_brain.app:app --host 0.0.0.0 --port 8001 &
KB_PID=$!
uvicorn task3_meeting_scope.app:app --host 0.0.0.0 --port 8003 &
SCOPE_PID=$!
trap 'kill $KB_PID $SCOPE_PID 2>/dev/null || true' EXIT
cd task2_inbox_agent
npm install
npm run dev
