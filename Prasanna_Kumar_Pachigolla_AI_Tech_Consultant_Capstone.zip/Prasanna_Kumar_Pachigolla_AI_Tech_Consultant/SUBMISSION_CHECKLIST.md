# Submission Checklist — Prasanna Kumar Pachigolla

- [ ] Confirm full implementation against the official PDF.
- [ ] Implement and test Claude vision descriptions for screenshots (known gap).
- [ ] Run `docker compose up --build` successfully.
- [ ] Ingest the official sitemap in bounded batches and inspect error/removal reports.
- [ ] Test Task 2 using at least 50 realistic emails and submit human feedback.
- [ ] Run at least 20 tests per task; fill actual results, latency and cost.
- [ ] Compare at least two Claude models/configurations on the same evaluation set.
- [ ] Role-play and record 3 client meetings; use the supplied transcripts as initial examples.
- [ ] Demonstrate a follow-up scope diff, estimates, proposal and human approval.
- [ ] Record demo video under 10 minutes; face visible for first 30 seconds; show success and failure.
- [ ] Export actual allowed AI coding-assistant conversation logs; ensure the chosen tool matches the assignment rule.
- [ ] Push one repo with sensible commits over the required work period. Do not fabricate commit history.
- [ ] Never upload `.env`, API keys or private client data.
