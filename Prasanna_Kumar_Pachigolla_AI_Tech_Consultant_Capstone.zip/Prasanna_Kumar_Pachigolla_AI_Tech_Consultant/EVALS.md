# Evaluation Plan
**Prepared by Prasanna Kumar Pachigolla**

The full case lists are in `evals/TASK1_EVALS.md`, `evals/TASK2_EVALS.md` and `evals/TASK3_EVALS.md`. Each task has 20 scenarios. These are test plans, not completed measurements: actual results remain pending until executed.

## What I measure
- **Quality:** correct result against a written expected behaviour; source grounding; required fields; completeness.
- **Safety:** invented policies, unsafe autonomous replies, unapproved commercial commitments, and handling of malicious input.
- **Reliability:** HTTP errors, retries, valid structured output, and successful recovery.
- **Speed:** end-to-end latency, p50 and p95.
- **Cost:** model input/output tokens and estimated cost per successful task using the provider's current pricing at test time.

## Model comparison
Run the same frozen cases with two Claude model configurations, recording exact model IDs and prompt versions. Do not compare models using different inputs. A model wins only if quality and safety remain acceptable while cost/latency improve. There are no claimed accuracy percentages or cost figures in this repository because no full model evaluation has been executed.

## Release gates
- Knowledge answers must cite sources; unsupported answers must escalate.
- Inbox must not autonomously send refunds, complaints, quotes or other sensitive messages.
- Scope/proposal output must require human approval and expose assumptions and open questions.
- A regression suite must be rerun after prompt, model or retrieval changes.
