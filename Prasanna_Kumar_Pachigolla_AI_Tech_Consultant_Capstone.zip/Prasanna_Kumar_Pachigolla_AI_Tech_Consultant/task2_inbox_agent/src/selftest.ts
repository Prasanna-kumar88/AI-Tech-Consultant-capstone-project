import assert from "node:assert/strict";
// Small deterministic tests for email kind classification are exercised through a local duplicate
// to keep this test independent of starting the HTTP server.
function classify(subject: string, body: string): string {
  const t = `${subject} ${body}`.toLowerCase();
  if (/refund|cancel|chargeback/.test(t)) return "refund_or_cancellation";
  if (/bug|error|not working|broken|failed/.test(t)) return "technical_issue";
  if (/quote|price|estimate|proposal|new project/.test(t)) return "sales_or_quote";
  if (/complaint|unhappy|angry|poor service/.test(t)) return "complaint";
  if (/follow.?up|status|update/.test(t)) return "follow_up";
  if (/how do i|how can i|where is|help me/.test(t)) return "how_to";
  return "general";
}
assert.equal(classify("Help", "How do I update my profile?"), "how_to");
assert.equal(classify("Refund request", "Please cancel my plan"), "refund_or_cancellation");
assert.equal(classify("Bug", "The page is broken"), "technical_issue");
assert.equal(classify("Quote", "I need a project estimate"), "sales_or_quote");
console.log("Inbox Agent deterministic smoke tests passed.");
