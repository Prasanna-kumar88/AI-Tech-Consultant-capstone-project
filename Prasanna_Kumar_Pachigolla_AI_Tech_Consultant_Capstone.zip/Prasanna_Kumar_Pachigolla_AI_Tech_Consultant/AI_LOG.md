# AI Tool Log
**Prepared by Prasanna Kumar Pachigolla**

The assignment asks for five useful prompts and one rejected AI answer. I am recording the prompts used to structure this implementation; I must replace or supplement this with the actual conversation export from the one coding assistant used during the four-day project. This file is not a claim that a particular tool conversation has been exported.

## Five useful prompts
1. “Read the capstone brief and turn every explicit requirement into a task-by-task checklist. Do not assume requirements that are not in the source.”
2. “Design a sitemap crawler that persists each successful page, respects rate limits, detects content changes and does not delete data if the sitemap fetch fails.”
3. “Implement the Inbox Agent in strict TypeScript. Validate input, call the Knowledge Brain API, record human edits, and make the 20 unchanged-draft rule a safety gate.”
4. “Design a multi-agent scope workflow that checks existing product functionality before estimating custom work and compares follow-up transcripts against the prior scope.”
5. “Create 20 evaluation cases per task. Clearly label unexecuted cases and do not fabricate quality, cost or latency results.”

## Rejected answer / decision
I rejected the idea of claiming that the initial implementation was complete or production-ready. The official brief requires actual screenshot understanding, TypeScript for Task 2 by default, learning from sent emails, multi-agent estimates/proposals, measured model comparisons and a demo. Those capabilities cannot honestly be claimed without implementation and testing. This revised project still has known gaps, especially full image understanding and executed evaluation metrics.
