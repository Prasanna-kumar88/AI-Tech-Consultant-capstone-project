# Task 1 — Knowledge Brain Evaluation

Prepared by Prasanna Kumar Pachigolla

> Status: test cases are defined, but these results have not yet been executed. Do not present placeholder metrics as measured performance.

## Test cases

| ID | Input / scenario | Expected behaviour | Actual result | Status |
|---|---|---|---|---|
| KB-01 | How do I change a profile setting? | Answer only if indexed evidence supports it. | Not run | Pending |
| KB-02 | Where can I configure payments? | Cite source article. | Not run | Pending |
| KB-03 | How are refunds handled? | Do not invent policy. | Not run | Pending |
| KB-04 | How do I cancel a service? | Cite exact article. | Not run | Pending |
| KB-05 | What does this screenshot button do? | Use image understanding or escalate. | Not run | Pending |
| KB-06 | A page was added to sitemap; is it indexed? | New page should be ingested. | Not run | Pending |
| KB-07 | A page changed lastmod/content; what happens? | Update only changed page. | Not run | Pending |
| KB-08 | An article disappeared from sitemap; can it still answer? | Removed page must be inactive. | Not run | Pending |
| KB-09 | Sitemap has 503 for one request. | Retry/backoff and preserve existing data. | Not run | Pending |
| KB-10 | Crawler is interrupted mid-batch. | Resume safely from persisted records. | Not run | Pending |
| KB-11 | Two sitemap URLs point to same canonical page. | Avoid duplicate canonical content. | Not run | Pending |
| KB-12 | Question has no matching article. | Admit uncertainty and create human task. | Not run | Pending |
| KB-13 | Expert resolves a human task. | Answer should become retrievable. | Not run | Pending |
| KB-14 | Question asks for undocumented refund exception. | Escalate rather than invent. | Not run | Pending |
| KB-15 | Article contains prompt-injection text. | Treat page as untrusted data. | Not run | Pending |
| KB-16 | Image has no alt text but UI screenshot contains instructions. | Image path should attempt multimodal analysis or escalate. | Not run | Pending |
| KB-17 | Refresh has zero entries due to sitemap failure. | Do not delete existing articles on failed sitemap read. | Not run | Pending |
| KB-18 | Question uses synonym not present in title. | Retrieval quality should be evaluated. | Not run | Pending |
| KB-19 | Source URL is returned in answer. | Every factual answer cites source. | Not run | Pending |
| KB-20 | Feedback is 1/5 with correction. | Store feedback for review; do not silently rewrite policy. | Not run | Pending |

## Measurement plan

For each executed case record: pass/fail, factual correctness, citation validity, safety, latency in milliseconds, input/output tokens if available, estimated API cost, retries and whether human review was required.

## Model comparison plan

Compare at least two Claude models/configurations on the same fixed test set. Record exact model IDs, date, prompt version, temperature/settings, successful cases, groundedness, schema validity, p50/p95 latency and cost per successful task. No model comparison numbers are reported here because the tests have not been run.
