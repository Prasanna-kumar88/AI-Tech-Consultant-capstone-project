# Task 2 — Inbox Agent Evaluation

Prepared by Prasanna Kumar Pachigolla

> Status: test cases are defined, but these results have not yet been executed. Do not present placeholder metrics as measured performance.

## Test cases

| ID | Input / scenario | Expected behaviour | Actual result | Status |
|---|---|---|---|---|
| INBOX-01 | How do I reset my password? | how_to | Not run | Pending |
| INBOX-02 | Please refund my last charge | refund_or_cancellation | Not run | Pending |
| INBOX-03 | Cancel before renewal | refund_or_cancellation | Not run | Pending |
| INBOX-04 | My page crashes on save | technical_issue | Not run | Pending |
| INBOX-05 | Please quote a CRM integration | sales_or_quote | Not run | Pending |
| INBOX-06 | I am unhappy with the delay | complaint | Not run | Pending |
| INBOX-07 | Following up on ticket 41 | follow_up | Not run | Pending |
| INBOX-08 | Where can I update my logo? | how_to | Not run | Pending |
| INBOX-09 | Unexpected duplicate charge | refund_or_cancellation | Not run | Pending |
| INBOX-10 | Could you send a proposal? | sales_or_quote | Not run | Pending |
| INBOX-11 | I cannot log in | technical_issue | Not run | Pending |
| INBOX-12 | You have not replied for a week | complaint | Not run | Pending |
| INBOX-13 | Is there an update on my request? | follow_up | Not run | Pending |
| INBOX-14 | What are your support hours? | general | Not run | Pending |
| INBOX-15 | Email notifications stopped | technical_issue | Not run | Pending |
| INBOX-16 | Can you make an exception? | complaint | Not run | Pending |
| INBOX-17 | Need a cost estimate | sales_or_quote | Not run | Pending |
| INBOX-18 | How can I add staff? | how_to | Not run | Pending |
| INBOX-19 | Delete my account | general | Not run | Pending |
| INBOX-20 | A customer asks for another customer's data | general | Not run | Pending |

## Measurement plan

For each executed case record: pass/fail, factual correctness, citation validity, safety, latency in milliseconds, input/output tokens if available, estimated API cost, retries and whether human review was required.

## Model comparison plan

Compare at least two Claude models/configurations on the same fixed test set. Record exact model IDs, date, prompt version, temperature/settings, successful cases, groundedness, schema validity, p50/p95 latency and cost per successful task. No model comparison numbers are reported here because the tests have not been run.
